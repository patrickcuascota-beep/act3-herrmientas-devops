const apm = require("elastic-apm-node").start({
  serviceName: process.env.APM_SERVICE_NAME || "apollo-fintech-app",

  // URL del servidor APM.
  // Usamos una variable de entorno para inyectarla desde Terraform.
  serverUrl: process.env.APM_SERVER_URL || "http://localhost:8200",
  secretToken: process.env.APM_SECRET_TOKEN || "",
  environment: process.env.NODE_ENV || "production",
});

// Verificación en consola para saber si APM arrancó
if (apm.isStarted()) {
  console.log("✅ Elastic APM Agent iniciado correctamente.");
} else {
  console.log(
    "❌ Elastic APM Agent no se ha iniciado (revisa la configuración).",
  );
}

const { ApolloServer, gql } = require("apollo-server");

const typeDefs = gql`
  type Book {
    title: String
    author: String
  }

  type Query {
    books: [Book]
  }
`;

const books = [
  {
    title: "The Awakening",
    author: "Kate Chopin",
  },
  {
    title: "City of Glass",
    author: "Paul Auster",
  },
  {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
  },
  {
    title: "1984",
    author: "George Orwell",
  },
  {
    title: "Pride and Prejudice",
    author: "Jane Austen",
  },
  {
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
  },
];

// Resolvers
const resolvers = {
  Query: {
    books: () => books,
  },
};

// Inicialización del servidor
const server = new ApolloServer({ typeDefs, resolvers });

const PORT = process.env.PORT || 4000;

server
  .listen({ port: PORT })
  .then(({ url }) => {
    console.log(`🚀  Server ready at ${url}`);
  })
  .catch((err) => {
    console.error("❌ Error starting server:", err);
  });
